import { useEffect, useRef } from "react";
import { gsap } from "gsap";

export default function HeartSVG() {
  const pathRef = useRef(null);

  useEffect(() => {
    const path = pathRef.current;
    const length = path.getTotalLength();

    // Set initial stroke styles
    path.style.strokeDasharray = length;
    path.style.strokeDashoffset = length;
    path.style.stroke = "#995098"; // stroke color
    path.style.fill = "transparent"; // ensure fill is transparent
    path.style.strokeWidth = "3";

    // Animate the path
    gsap.to(path, {
      strokeDashoffset: 0,
      duration: 2,
      ease: "power2.out",
      repeat: -1, // infinite loop
      yoyo: true, // reverse on repeat
    });
  }, []);

  return (
    <svg
      width="200"
      height="200"
      viewBox="0 0 512 512"
      xmlns="http://www.w3.org/2000/svg"
    >
      <path
        ref={pathRef}
        d="M97.344,482.17c-23.311,0-45.215-9.084-61.689-25.555c-34.01-34.014-34.01-89.361,0-123.371L305.343,63.543
        c21.727-21.75,50.645-33.713,81.39-33.713c30.75,0,59.667,11.963,81.395,33.713c21.748,21.744,33.726,50.645,33.726,81.389
        c0,30.75-11.964,59.65-33.708,81.381L255.843,438.596c-6.374,6.371-16.696,6.371-23.067,0c-6.374-6.373-6.374-16.695,0-23.07
        l212.298-212.283c15.583-15.58,24.153-36.291,24.153-58.311c0-22.016-8.588-42.74-24.167-58.322
        c-15.583-15.58-36.294-24.154-58.327-24.154c-22.029,0-42.74,8.574-58.323,24.154L58.725,356.311
        c-21.283,21.301-21.283,55.938,0,77.234c20.645,20.617,56.589,20.617,77.233,0l181.091-181.105
        c4.924-4.924,7.745-11.74,7.745-18.688c0-7.045-2.755-13.686-7.759-18.689c-10.291-10.291-27.067-10.322-37.358,0L156,338.754
        c-6.37,6.375-16.697,6.375-23.067,0c-6.374-6.371-6.374-16.697,0-23.066l123.673-123.691c23.005-23.004,60.461-23.004,83.497,0
        c11.169,11.166,17.317,26,17.317,41.756c0,15.547-6.308,30.762-17.3,41.754L159.029,456.615
        C142.555,473.086,120.65,482.17,97.344,482.17z"
      />
    </svg>
  );
}
