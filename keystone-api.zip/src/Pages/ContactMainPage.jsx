import Header from "../Components/Header";
import ContactPage from "../Components/ContactPage";
import AOS from "aos";
import "aos/dist/aos.css";

export default function ContactMainPage() {
  return (
    <>
      <div>
        {/* <Header /> */}
        <ContactPage />
      </div>
    </>
  );
}
