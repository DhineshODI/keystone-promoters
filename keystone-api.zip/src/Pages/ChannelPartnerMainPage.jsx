import ChannelPartnerComponent from "../Components/ChannelPartnerComponent";
import ContactPage from "../Components/ContactPage";
import Header from "../Components/Header";
import AOS from "aos";
import "aos/dist/aos.css";

export default function ChannelPartner() {
  return (
    <>
      <div>
        {/* <Header /> */}
        <ChannelPartnerComponent />
      </div>
    </>
  );
}
