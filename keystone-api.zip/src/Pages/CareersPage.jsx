import CareerPageFunction from "../Components/CareerPageComponent";
import ContactPage from "../Components/ContactPage";
import Header from "../Components/Header";
import AOS from "aos";
import "aos/dist/aos.css";

export default function CareersPage() {
  return (
    <>
      <div>
        {/* <Header /> */}
        <CareerPageFunction />
      </div>
    </>
  );
}
